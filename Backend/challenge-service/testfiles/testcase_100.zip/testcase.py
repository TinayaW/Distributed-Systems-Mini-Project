from run import add

def run_test_cases():
    test_cases = [
        (2, 3, 5),
        (-2, -3, -5),
        (0, 5, 5),
        (0, -5, -5),
        (10, -5, 5)
    ]
    
    passed = 0
    failed = 0
    
    for idx, (a, b, expected_result) in enumerate(test_cases):
        result = add(a, b)
        if result == expected_result:
            passed += 1
        else:
            failed += 1
    
    score = (passed/(failed+passed))*100
    print(score)

run_test_cases()
